import UIKit

struct Person {
    var name: String
    var DOB: String
}

let newStudent = Person(name: "razan", DOB: "24-25-2000")

print(newStudent)

print("Task 2 :")

struct Employee {
    var id: Int
    var name: String
    var department: String
    
    func printDetails() {
        print("Employee ID: \(id) Name: \(name) Department: \(department)")
    }
}

class Company {
    var employees: [Employee] = []
    
    
    func addEmployee(id: Int, name: String, department: String) {
          var employee = Employee(id: id, name: name, department: department)
          employees.append(employee)
      }
    func listEmployees() {
                print("List of Employees:")
                for employee in employees {
                    employee.printDetails()
                    print("----------")
                }
            }
}

var company = Company()
company.addEmployee(id: 1, name: "Razan Alshatti", department: "IT")
company.addEmployee(id: 2, name: "Nada Alshaibani", department: "IT")
company.addEmployee(id: 3, name: "Fares Alfares", department: "Human Resources")

company.listEmployees()
